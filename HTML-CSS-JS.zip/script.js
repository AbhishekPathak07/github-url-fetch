// Function to fetch repository details from GitHub API
async function fetchRepoDetails(username, repo) {
  try {
    const response = await fetch(`https://api.github.com/repos/${username}/${repo}`);
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error fetching repository details:', error);
  }
}

// Function to update HTML elements with fetched data
function updateUI() {
  document.getElementById('repo').textContent = repoDetails.full_name;
  document.getElementById('description').textContent = repoDetails.description;
  document.getElementById('forks').textContent = repoDetails.forks_count;
  document.getElementById('updated').textContent = new Date(repoDetails.updated_at).toLocaleDateString();
}

// Fetch repository details and update the UI
fetchRepoDetails('username', 'repository-name')
  .then(repoDetails => updateUI(repoDetails))
  .catch(error => console.error('Error in fetchRepoDetails:', error));